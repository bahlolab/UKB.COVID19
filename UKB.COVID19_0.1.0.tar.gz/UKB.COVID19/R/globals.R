
utils::globalVariables(c("epistart", ".", "sourceAged",
                         "admisorc_uni", "dischargeAged", 
                         "disdest_uni", "eid", "reqorg", 
                         "perstype", "factype"))