library(testthat)
library(UKB.COVID19)

test_check("UKB.COVID19")
